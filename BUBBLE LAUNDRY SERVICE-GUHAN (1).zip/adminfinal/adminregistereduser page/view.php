<!DOCTYPE html>
<html>
<head>
    <style>
        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 300px;
        }

        input[type="submit"] {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    include_once 'dbconnect.php';
    if (isset($_GET['username'])) {
        $username = $_GET['username'];

        // Database connection
        $mysqli = new mysqli("localhost", "root", "", "project");
        if ($mysqli->connect_error) {
            die("Connection failed: " . $mysqli->connect_error);
        }

        // Fetch record details
        $stmt = $mysqli->prepare("SELECT * FROM register WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
    ?>
            <h1>Record Details</h1>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($row["username"]); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($row["email"]); ?></p>
            <p><strong>Place:</strong> <?php echo htmlspecialchars($row["place"]); ?></p>
            <p><strong>Phone:</strong> <?php echo htmlspecialchars($row["phone"]); ?></p>

    <?php
        } else {
            echo "No record found.";
        }

        $stmt->close();
        $mysqli->close();
    } else {
        echo "Invalid request.";
    }
    ?>
</body>
</html>