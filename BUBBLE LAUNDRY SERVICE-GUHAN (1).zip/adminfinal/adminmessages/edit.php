<!DOCTYPE html>
<html>
<head>
    <style>
        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"], input[type="email"], input[type="message"] {
            width: 300px;
        }

        input[type="submit"] {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    // Function to sanitize user input
    function sanitizeInput($input)
    {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        return $input;
    }

    // Fetch record details
    if (isset($_GET['username'])) {
        $username = $_GET['username'];

        // Database connection
        $mysqli = new mysqli("localhost", "root", "", "project");
        if ($mysqli->connect_error) {
            die("Connection failed: " . $mysqli->connect_error);
        }

        // Fetch record details
        $stmt = $mysqli->prepare("SELECT * FROM messages WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            // Form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $email = sanitizeInput($_POST['email']);
                $place = sanitizeInput($_POST['message']);


                // Update record
                $updateStmt = $mysqli->prepare("UPDATE messages SET email = ?, msg = ? WHERE username = ?");
                $updateStmt->bind_param("sssss", $email, $message, $username);
                if ($updateStmt->execute()) {
                    echo "Record edited successfully.";
                    $row["email"] = $email; // Update the email value in the $row variable
                    $row["msg"] = $place; // Update the place value in the $row variable
                } else {
                    echo "Error editing record: " . $updateStmt->error;
                }

                $updateStmt->close();
            }
            ?>
            
            <h1>Record Details</h1>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($row["username"]); ?></p>
            
            <form method="POST" action="">
                <label for="email">Email:</label>
                <input type="email" name="email" value="<?php echo sanitizeInput($row["email"]); ?>" required><br>

                <label for="msg">Message:</label>
                <input type="text" name="msg" value="<?php echo sanitizeInput($row["msg"]); ?>" required><br>
                <input type="submit" name="submit" value="Submit">
            </form>
            
            <?php
        } else {
            echo "No record found.";
        }

        $stmt->close();
        $mysqli->close();
    } else {
        echo "Invalid request.";
    }
    ?>

</body>
</html>