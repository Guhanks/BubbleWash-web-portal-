<!DOCTYPE html>
<html>
<head>
    <style>
        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            width: 300px;
        }

        input[type="submit"] {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    include_once 'dbconnect.php';
    // Function to sanitize user input
    function sanitizeInput($input)
    {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        return $input;
    }

    // Form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = sanitizeInput($_POST['username']);
        $email = sanitizeInput($_POST['email']);
        $place = sanitizeInput($_POST['place']);
        $phone = sanitizeInput($_POST['phone']);
        $password = sanitizeInput($_POST['password']);

        

        // Insert record
        $stmt = $mysqli->prepare("INSERT INTO register (username, email, place, phone, pass) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $email, $place, $phone, $password);
        if ($stmt->execute()) {
            echo "Record inserted successfully.";
            echo '<script>
                    setTimeout(function() {
                        window.location.href = "adminregistereduser.php";
                    }, 3000); // 3000 milliseconds = 3 seconds
                </script>';
        } else {
            echo "Error inserting record: " . $stmt->error;
        }

        $stmt->close();
        $mysqli->close();
    }
    ?>

    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="place">Place:</label>
        <input type="text" name="place" required><br>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" name="submit" value="Submit">
    </form>

</body>
</html>