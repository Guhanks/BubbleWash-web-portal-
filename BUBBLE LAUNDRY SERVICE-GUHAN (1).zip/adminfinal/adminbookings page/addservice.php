<?php
$servername = "localhost";
$dbname = "project";
$username = "root";
$password = "";

// Creating a new connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Checking the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Retrieve the latest booking ID from the database and increment it
$query = "SELECT MAX(booking_id) AS max_booking_id FROM booking";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$bookingId = $row['max_booking_id'];
if ($bookingId) {
  $bookingId = substr($bookingId, 2); // Remove the 'BK' prefix
  $bookingId = intval($bookingId); // Convert to integer
  $bookingId++; // Increment
  $bookingId = 'BK' . str_pad($bookingId, 3, '0', STR_PAD_LEFT); // Add the 'BK' prefix and zero-padding
} else {
  $bookingId = 'BK001'; // Initial booking ID
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $customerName = $_POST['customer_name'];
  $serviceType = $_POST['service_type'];
  $clothType = $_POST['cloth_type'];
  $weightCombination = $_POST['weight_combination'];
  $exactWeight = $_POST['exact_weight'];

  // Calculating the price based on service type and cloth type
  $price = 0;
  if (($serviceType == 'dry_clean' || $serviceType == 'steam_iron') && ($clothType == 'shirt' || $clothType == 'tshirt' || $clothType == 'saree' || $clothType == 'chudi' || $clothType == 'suit_pant')) {
    $price = 10; // Price for dry clean and steam iron with cloth types shirt, tshirt, saree, chudi, suit-pant
  } elseif ($serviceType == 'bag_toy_wash' && ($clothType == 'nylon' || $clothType == 'woolen' || $clothType == 'jute')) {
    $price = 6; // Price for bag and toy wash with cloth types nylon, woolen, jute
  }

  // Calculating the discount based on weight
  $discount = 0;
  if ($weightCombination == 'less_than_10') {
    $discount = $price * $exactWeight * 0.05; // 5% discount for less than 10 kg
  } elseif ($weightCombination == 'more_than_10') {
    $discount = $price * $exactWeight * 0.2; // 20% discount for more than 10 kg
  }

  // Calculating the total price
  $totalPrice = $price * $exactWeight - $discount;

  $pickupDate = $_POST['pickup_date'];
  $deliveryDate = $_POST['delivery_date'];

  // Prepare the INSERT statement
  $query = "INSERT INTO booking (booking_id, customer_name, service_type, cloth_type, weight_combination, exact_weight, price, discount, total_price, pickup_date, delivery_date)
            VALUES ('$bookingId', '$customerName', '$serviceType', '$clothType', '$weightCombination', $exactWeight, $price, $discount, $totalPrice, '$pickupDate', '$deliveryDate')";

  // Execute the INSERT statement
    if (mysqli_query($conn, $query)) {
        $insertionMessage = "<p style='color: green;'>Booking Successful</p>";
        echo "<script>
        // Clear form fields
        document.getElementById('customer-name').value = '';
        document.getElementById('service-type').value = '';
        document.getElementById('cloth-type').value = '';
        document.getElementById('weight-combination').value = '';
        document.getElementById('exact-weight').value = '';
        document.getElementById('pickup-date').value = '';
        document.getElementById('delivery-date').value = '';
        document.getElementById('price').value = '';
        document.getElementById('discount').value = '';
        document.getElementById('total-price').value = '';
      </script>";
      } else {
        $insertionMessage = "<p style='color: red;'>Error: " . mysqli_error($conn) . "</p>";
      }
  // Close the connection
  mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Booking Form</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }

    h1 {
      color: #333;
    }

    form {
      max-width: 400px;
      margin: 0 auto;
    }

    label {
      display: block;
      margin-bottom: 8px;
      color: #555;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      font-size: 14px;
      margin-bottom: 16px;
    }

    input[type="radio"] {
      margin-right: 8px;
    }

    input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 10px 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
  <script type="text/javascript">
    function updateClothTypes() {
      var serviceType = document.getElementById("service_type").value;
      var clothTypeSelect = document.getElementById("cloth_type");
      clothTypeSelect.innerHTML = ""; // Clear the existing options

      if (serviceType === "dry_clean" || serviceType === "steam_iron") {
        var clothTypes = ["shirt", "tshirt", "saree", "chudi", "suit_pant"];
      } else if (serviceType === "bag_toy_wash") {
        var clothTypes = ["nylon", "woolen", "jute"];
      }

      for (var i = 0; i < clothTypes.length; i++) {
        var option = document.createElement("option");
        option.value = clothTypes[i];
        option.text = clothTypes[i].charAt(0).toUpperCase() + clothTypes[i].slice(1);
        clothTypeSelect.appendChild(option);
      }

      updateCalculatedValues();
    }

    function updateCalculatedValues() {
      var priceInput = document.querySelector("input[name='price']");
      var discountInput = document.querySelector("input[name='discount']");
      var totalPriceInput = document.querySelector("input[name='total_price']");
      var serviceType = document.getElementById("service_type").value;
      var clothType = document.getElementById("cloth_type").value;
      var weightCombination = document.querySelector("input[name='weight_combination']:checked").value;
      var exactWeight = parseFloat(document.querySelector("input[name='exact_weight']").value);

      var price = 0;
      if ((serviceType === 'dry_clean' || serviceType === 'steam_iron') && (clothType === 'shirt' || clothType === 'tshirt' || clothType === 'saree' || clothType === 'chudi' || clothType === 'suit_pant')) {
        price = 10; // Price for dry clean and steam iron with cloth types shirt, tshirt, saree, chudi, suit-pant
      } else if (serviceType === 'bag_toy_wash' && (clothType === 'nylon' || clothType === 'woolen' || clothType === 'jute')) {
        price = 6; // Price for bag and toy wash with cloth types nylon, woolen, jute
      }

      var discount = 0;
      if (weightCombination === 'less_than_10') {
        discount = price * exactWeight * 0.05; // 5% discount for less than 10 kg
      } else if (weightCombination === 'more_than_10') {
        discount = price * exactWeight * 0.2; // 20% discount for more than 10 kg
      }

      var totalPrice = price * exactWeight - discount;

      priceInput.value = price.toFixed(2);
      discountInput.value = discount.toFixed(2);
      totalPriceInput.value = totalPrice.toFixed(2);
    }
    window.addEventListener("load", function () {
      // Clear form fields
      document.getElementById("customer_name").value = "";
      document.getElementById("service_type").value = "";
      document.getElementById("cloth_type").value = "";
      document.getElementById("weight_combination").value = "";
      document.getElementById("exact_weight").value = "";
      document.getElementById("pickup_date").value = "";
      document.getElementById("delivery_date").value = "";
      document.getElementById("price").value = "";
      document.getElementById("discount").value = "";
      document.getElementById("total_price").value = "";
    });
  </script>
</head>
<body>
  <h1>Booking Form</h1>
  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="customer_name">Customer Name:</label>
    <input type="text" name="customer_name" required><br>

    <label for="service_type">Service Type:</label>
    <select name="service_type" id="service_type" onchange="updateClothTypes()" required>
      <option value="dry_clean">Dry Clean</option>
      <option value="steam_iron">Steam Iron</option>
      <option value="bag_toy_wash">Bag and Toy Wash</option>
    </select><br>

    <label for="cloth_type">Cloth Type:</label>
    <select name="cloth_type" id="cloth_type" onchange="updateCalculatedValues()" required></select><br>

    <label for="weight_combination">Weight Combination:</label>
    <input type="radio" name="weight_combination" value="less_than_10" onchange="updateCalculatedValues()" required> Less than 10 kg
    <input type="radio" name="weight_combination" value="more_than_10" onchange="updateCalculatedValues()" required> More than 10 kg<br>

    <label for="exact_weight">Exact Weight:</label>
    <input type="number" name="exact_weight" onchange="updateCalculatedValues()" required><br>

    <label for="pickup_date">Pickup Date:</label>
    <input type="date" name="pickup_date" required><br>

    <label for="delivery_date">Delivery Date:</label>
    <input type="date" name="delivery_date" required><br>

    <label for="price">Price:</label>
    <input type="number" name="price" readonly><br>

    <label for="discount">Discount:</label>
    <input type="number" name="discount" readonly><br>

    <label for="total_price">Total Price:</label>
    <input type="number" name="total_price" readonly><br>

    <input type="submit" value="Submit">
  </form>

</body>
</html>
<