<?php
session_start();
// Logout functionality
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["logout"])) {
    // Destroy session and redirect to login page
    session_destroy();
    header("location: login.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Admin Dashboard </title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="admindashboard.css">
</head>

<body>
    <?php
    include_once "dbconnect.php";
    ?>
    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <img src="logo.jpg">
                    <span class="title">Bubble wash laundry service</span>
                </li>

                <li>
                    <a href="admindashboard.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="./adminregistereduser page/adminregistereduser.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Registered Users</span>
                    </a>
                </li>

                <li>
                    <a href="./adminmessages/adminmessage.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Messages</span>
                    </a>
                </li>

                <li>
                    <a href="subadmin.php">
                        <span class="icon">
                            <ion-icon name="lock-closed-outline"></ion-icon>
                        </span>
                        <span class="title">subadmin</span>
                    </a>
                </li>

                <li>
                    <a href="../login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
                <li class="bookings-menu">
            <a href="./adminbookings page/adminbookings.php" class="bookings-toggle">
                <span class="icon">
                    <ion-icon name="briefcase-outline"></ion-icon>
                </span>
                <span class="title">Bookings</span>
            </a>
             </li>
            </ul>
        </div>
    </div>

    <!-- ========================= Main ==================== -->
    <div class="main">
        <div class="topbar">
            <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
            </div>
        </div>

        <div class="user">
            <img src="../img/userprofile.png" alt=""><br><br>
        </div>
        <h4 class="login">Welcome, <?php echo $_SESSION["username"]; ?></h4><br><br>
         <h1>ADMIN DASHBOARD</h1><br><br>
        <!-- ======================= Cards ================== -->
        <div class="cardBox">
            <div class="card">
                <div>
                    <div class="numbers">
                        <?php
                        $sql = "SELECT COUNT(*) AS count FROM register";
                        $result = $conn->query($sql);
                        $count = 0;

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $count = $row['count'];
                            echo $count;
                        }
                        ?>
                    </div>
                    <div class="cardName">Registered Users</div>
                </div>

                <div class="iconBx">
                    <ion-icon name="people-outline"></ion-icon>
                </div>
            </div>

            <div class="card">
                <div>
                    <div class="numbers">
                        <?php
                        // Assuming you have a database connection established
                        $sql = "SELECT COUNT(*) AS count FROM booking";
                        $result = $conn->query($sql);
                        $count = 0;

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $count = $row['count'];
                            echo $count;
                        }
                        ?>
                    </div>
                    <div class="cardName">Total Bookings</div>
                </div>

                <div class="iconBx">
                    <ion-icon name="cart-outline"></ion-icon>
                </div>
            </div>

            <div class="card">
                <div>
                    <div class="numbers">
                        <?php
                        // Assuming you have a database connection established
                        $sql = "SELECT COUNT(*) AS count FROM messages";
                        $result = $conn->query($sql);
                        $count = 0;

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $count = $row['count'];
                            echo $count;
                        }
                        ?>

                    </div>
                    <div class="cardName">Messages</div>
                </div>

                <div class="iconBx">
                    <ion-icon name="chatbubble-outline"></ion-icon>
                </div>
            </div>
        </div>
        <script src="assets/js/main.js"></script>

        <!-- ====== ionicons ======= -->
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule
            src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

        <script>
            let list = document.querySelectorAll(".navigation li");

            function activeLink() {
                list.forEach((item) => {
                    item.classList.remove("hovered");
                });
                this.classList.add("hovered");
            }

            list.forEach((item) => item.addEventListener("mouseover", activeLink));

            // Menu Toggle
            let toggle = document.querySelector(".toggle");
            let navigation = document.querySelector(".navigation");
            let main = document.querySelector(".main");

            toggle.onclick = function () {
                navigation.classList.toggle("active");
                main.classList.toggle("active");
            };
        </script>
</body>

</html>
