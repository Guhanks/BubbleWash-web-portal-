<html>
    <head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<style>
/* =========== Google Fonts ============ */
@import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap");

/* =============== Globals ============== */
* {
  font-family: "Ubuntu", sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

:root {
  --white: #fff;
  --gray: #f5f5f5;
  --black1: #222;
  --black2: #999;
}

img {
    height: 50px;
    margin-right: 10px;
    width:60px;
    margin-left:2px;
}
.title
{
  color:white;
}
/* =============== Navigation ================ */
.navigation {
  position: fixed;
  width: 300px;
  height: 100%;
  background: var(--black1);
  border-left: 10px solid var(--black1);
  transition: 0.5s;
  overflow: hidden;
}
.navigation.active {
  width: 80px;
}

.navigation ul {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
}

.navigation ul li {
  position: relative;
  width: 100%;
  list-style: none;
  border-top-left-radius: 30px;
  border-bottom-left-radius: 30px;
}

.navigation ul li:hover,
.navigation ul li.hovered {
  background-color: var(--black2);
}

.navigation ul li:nth-child(1) {
  margin-bottom: 40px;
  pointer-events: none;
}

.navigation ul li a {
  position: relative;
  display: block;
  width: 100%;
  display: flex;
  text-decoration: none;
  color: var(--white);
}
.navigation ul li:hover a,
.navigation ul li.hovered a {
  color:;
}

.navigation ul li a .icon {
  position: relative;
  display: block;
  min-width: 60px;
  height: 60px;
  line-height: 75px;
  text-align: center;
}
.navigation ul li a .icon ion-icon {
  font-size: 1.75rem;
}

.navigation ul li a .title {
  position: relative;
  display: block;
  padding: 0 10px;
  height: 60px;
  line-height: 60px;
  text-align: start;
  white-space: nowrap;
}

/* --------- curve outside ---------- */
.navigation ul li:hover a::before,
.navigation ul li.hovered a::before {
  content: "";
  position: absolute;
  right: 0;
  top: -50px;
  width: 50px;
  height: 50px;
  background-color: transparent;
  border-radius: 50%;
  box-shadow: 35px 35px 0 10px var(--white);
  pointer-events: none;
}
.navigation ul li:hover a::after,
.navigation ul li.hovered a::after {
  content: "";
  position: absolute;
  right: 0;
  bottom: -50px;
  width: 50px;
  height: 50px;
  background-color: transparent;
  border-radius:5%;
  box-shadow: 35px -35px 0 10px var(--white);
  pointer-events: none;
}

.bookings-menu {
  position: relative; /* Updated to allow submenu positioning */
}

.bookings-submenu {
  position: absolute;
  top: 100%; /* Updated to appear below the bookings menu */
  left: 0;
  width: 200px;
  background-color:black;
  color:white;
  padding:0;
  border-radius:0;
  display: none;
  z-index: 1; 
}

.bookings-menu.active .bookings-submenu {
  margin-top:60px;
  display: block;
}

</style></head>
<body>
<div class="navigation">
            <ul>
                <li>
                        <img src=logo.jpg>     
                        <span class="title">Bubble wash laundry service</span>
                </li>

                <li>
                    <a href="../admindashboard.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="../adminregistereduser page/adminregistereduser.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Registered Users</span>
                    </a>
                </li>

                <li>
                    <a href="../adminmessages/adminmessage.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Messages</span>
                    </a>
                </li>

                <li>
                <li>
                    <a href="subadmin.php">
                        <span class="icon">
                            <ion-icon name="lock-closed-outline"></ion-icon>
                        </span>
                        <span class="title">subadmin</span>
                    </a>
                </li>

                <li>
                    <a href="../../login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                        
                    </a>
                </li>
                <li class="bookings-menu">
            <a  class="bookings-toggle">
                <span class="icon">
                    <ion-icon name="briefcase-outline"></ion-icon>
                </span>
                <span class="title">Bookings</span>
              </a>
            
            <ul class="bookings-submenu">
                <li></li>
                <li>
                    <a href="./viewbydryclean.php">View by Dry Clean</a><br>
                </li>
                <li>
                    <a href="./viewbysteamiron.php">View by Steam Iron</a><br>
                </li>
                <li>
                    <a href="./viewbytoywashing.php">View by Toy & bag Washing</a><br>
                </li>
                <li>
                    <a href="./viewbyshoewashing.php">View by Shoe Washing</a><br>
                </li>
            </ul>
        </li>
            </ul>
        </div>
        <script>
    document.addEventListener("DOMContentLoaded", function() {
        const bookingsMenu = document.querySelector(".bookings-menu");
        const bookingsToggle = document.querySelector(".bookings-toggle");

        bookingsToggle.addEventListener("click", function() {
            bookingsMenu.classList.toggle("active");
        });
    });
</script>
</body>
</html>