<?php
    include_once 'dbconnect.php';

if (isset($_GET['username'])) {
    $username = $_GET['username'];

    // Database connection
    $mysqli = new mysqli("localhost", "root", "", "project");
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Delete record
    $stmt = $mysqli->prepare("DELETE FROM messages WHERE username = ?");
    $stmt->bind_param("s", $username);

    if ($stmt->execute()) {
        echo "Record deleted successfully.";
        echo '<script>
                setTimeout(function() {
                    window.location.href = "adminmessage.php";
                }, 500); // 1000 milliseconds = 1 seconds
            </script>';
    } else {
        echo "Error deleting record: " . $stmt->error;
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo "Invalid request.";
}
?>