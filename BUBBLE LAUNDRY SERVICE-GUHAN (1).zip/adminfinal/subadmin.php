<?php
session_start();
include_once "dbconnect.php";

// Check if the user is the root user
if ($_SESSION['username'] === 'rootuser') {
  // Fetch user records from the register table
  $query = "SELECT username, user_type FROM register";
  $result = mysqli_query($conn, $query);
  
  if ($result) {
    ?>
    <table>
      <thead>
        <tr>
          <th>Username</th>
          <th>User Type</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
          <tr>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['user_type']; ?></td>
            <td>
              <form method="post" action="update_user_type.php">
                <input type="hidden" name="username" value="<?php echo $row['username']; ?>">
                <button type="submit" name="user_type" value="subadmin">Subadmin</button>
                <button type="submit" name="user_type" value="user">User</button>
              </form>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
    <?php
  } else {
    echo "Error: " . mysqli_error($connection);
  }
} else {
  echo "Access denied.";
}
?>
