<?php
session_start();
include_once "dbconnect.php";

// Check if the user is the root user
if ($_SESSION['username'] === 'rootuser') {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['user_type'])) {
    $username = $_POST['username'];
    $user_type = $_POST['user_type'];

    // Update the user_type column in the register table
    $query = "UPDATE register SET user_type = '$user_type' WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if ($result) {
      echo "User type updated successfully.";
    } else {
      echo "Error: " . mysqli_error($conn);
    }
  } else {
    echo "Invalid request.";
  }
} else {
  echo "Access denied.";
}
?>
