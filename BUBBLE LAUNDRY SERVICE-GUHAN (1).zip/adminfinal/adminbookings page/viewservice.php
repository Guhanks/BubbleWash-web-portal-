<!DOCTYPE html>
<html>
<head>
    <style>
        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 300px;
        }

        input[type="submit"] {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    include_once 'dbconnect.php';
    if (isset($_GET['booking_id'])) {
        $bookingId = $_GET['booking_id'];
    
        // Database connection
        $mysqli = new mysqli("localhost", "root", "", "project");
        if ($mysqli->connect_error) {
            die("Connection failed: " . $mysqli->connect_error);
        }

        // Fetch record details
        $stmt = $mysqli->prepare("SELECT * FROM booking WHERE booking_id = ?");
        $stmt->bind_param("s", $bookingId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
    ?>
            <h1>Record Details</h1>
            <p><strong>Booking Id:</strong> <?php echo htmlspecialchars($row["booking_id"]); ?></p>
            <p><strong>Customer Name:</strong> <?php echo htmlspecialchars($row["customer_name"]); ?></p>
            <p><strong>Service Type:</strong> <?php echo htmlspecialchars($row["service_type"]); ?></p>
            <p><strong>Cloth Type:</strong> <?php echo htmlspecialchars($row["cloth_type"]); ?></p>
            <p><strong>Weight Combination:</strong> <?php echo htmlspecialchars($row["weight_combination"]); ?></p>
            <p><strong>Exact Weight:</strong> <?php echo htmlspecialchars($row["exact_weight"]); ?></p>
            <p><strong>Price:</strong> <?php echo htmlspecialchars($row["price"]); ?></p>
            <p><strong>Discount:</strong> <?php echo htmlspecialchars($row["discount"]); ?></p>
            <p><strong>Total Price :</strong> <?php echo htmlspecialchars($row["total_price"]); ?></p>
            <p><strong>Pickup Date:</strong> <?php echo htmlspecialchars($row["pickup_date"]); ?></p>
            <p><strong>Delivery Date:</strong> <?php echo htmlspecialchars($row["delivery_date"]); ?></p>
    <?php
        } else {
            echo "No record found.";
        }

        $stmt->close();
        $mysqli->close();
    } else {
        echo "Invalid request.";
    }
    ?>
</body>
</html>