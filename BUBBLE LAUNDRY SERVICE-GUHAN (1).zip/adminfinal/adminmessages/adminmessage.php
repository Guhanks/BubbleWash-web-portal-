<!DOCTYPE html>
<html>
<head>
    <style>

.main {
  position: absolute;
  width: calc(100% - 300px);
  min-height: 100vh;
  background: var(--white);
  transition :0.5s;
  margin-left: 10px;
}

.main.active {
  width: calc(100% - 80px);
  left: 80px;
}


        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:nth-child(odd) {
            background-color: #e5e5e5;
        }

        .btn-container {
            display: flex;
            gap: 10px;
        }

        .btn-container button {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
        }

        .add-user-btn {
            margin-bottom: 20px;
            border: none;
            background-color: green;
            color: white;
            padding: 5px 10px;
            cursor: pointer;
        }

        .view-btn {
            background-color: yellow;
        }

        .delete-btn {
            background-color: red;
        }

        .edit-btn {
            background-color: blue;
        }
        .toggle {
  cursor: pointer;
  margin-left: 40px;
}


.main {
  margin-left: 300px;
  transition: margin-left 0.3s ease-in-out;
}

.main.active {
  margin-left: 0;
}

.hovered {
  background: rgba(255, 255, 255, 0.1);
}
    </style>
</head>
<body>
    <?php
    // Include database connection file
    include_once 'dbconnect.php';
    include_once './adminsidebar.php';
    ?>
    <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
              </div>
              <h1>MESSAGES</h1>  
                  <?php
    // Function to sanitize user input
    function sanitizeInput($input)
    {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        return $input;
    }

    // Fetch all records
    $query = "SELECT * FROM messages";
    $result = $conn->query($query);
    ?>
         <div class="main">
    <table>
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Message</th>
            <th>Actions</th>
        </tr>
        <?php
        $rowNum = 0;
        while ($row = $result->fetch_assoc()) {
            $rowNum++;
            $rowColor = ($rowNum % 2 == 0) ? "#f9f9f9" : "#e5e5e5";

            echo "<tr style='background-color: $rowColor;'>";
            echo "<td>" . htmlspecialchars($row["username"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["msg"]) . "</td>";
            echo "<td>";
            echo "<div class='btn-container'>";
            echo "<button class='view-btn' onclick=\"viewRecord('" . htmlspecialchars($row["username"]) . "')\">View</button>";
            echo "<button class='edit-btn' onclick=\"editRecord('" . htmlspecialchars($row["username"]) . "')\">Edit</button>";
            echo "<button class='delete-btn' onclick=\"deleteRecord('" . htmlspecialchars($row["username"]) . "')\">Delete</button>";
            echo "</div>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    </div>

    <script>
        function viewRecord(username) {
            window.open("view.php?username=" + username, "_blank", "width=400,height=300");
        }

        function editRecord(username) {
            window.open("edit.php?username=" + username, "_blank", "width=400,height=400");
        }

        function deleteRecord(username) {
            if (confirm("Are you sure you want to delete this record?")) {
                window.location.href = "delete.php?username=" + username;
            }
        }
    </script>
 <script>
            // add hovered class to selected list item
            let list = document.querySelectorAll(".navigation li");

            function activeLink() {
                list.forEach((item) => {
                    item.classList.remove("hovered");
                });
                this.classList.add("hovered");
            }

            list.forEach((item) => item.addEventListener("mouseover", activeLink));

            // Menu Toggle
            let toggle = document.querySelector(".toggle");
            let navigation = document.querySelector(".navigation");
            let main = document.querySelector(".main");

            toggle.onclick = function () {
                navigation.classList.toggle("active");
                main.classList.toggle("active");
            };
        </script>
</body>
</html>










            