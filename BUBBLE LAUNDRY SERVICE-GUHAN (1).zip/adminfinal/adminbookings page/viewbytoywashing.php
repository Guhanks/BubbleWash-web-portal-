<!DOCTYPE html>
<html>
<head>
    <style>
    .main {
        position: absolute;
        width: calc(100% - 300px);
        min-height: 100vh;
        background: var(--white);
        transition: 0.5s;
        margin-left: 10px;
    }

    .main.active {
        width: calc(100% - 80px);
        left: 80px;
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        border: 1px solid black;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:nth-child(odd) {
        background-color: #e5e5e5;
    }

    .btn-container {
        display: flex;
        gap: 10px;
    }

    .btn-container button {
        padding: 5px 10px;
        border: none;
        cursor: pointer;
    }

    .add-user-btn {
        margin-bottom: 20px;
        border: none;
        background-color: green;
        color: white;
        padding: 5px 10px;
        cursor: pointer;
    }

    .view-btn {
        background-color: yellow;
    }

    .delete-btn {
        background-color: red;
    }

    .edit-btn {
        background-color: blue;
    }

    .toggle {
        cursor: pointer;
        margin-left: 40px;
    }

    .main {
        margin-left: 250px;
        transition: margin-left 0.3s ease-in-out;
    }

    .main.active {
        margin-left: 0;
    }

    .hovered {
        background: rgba(255, 255, 255, 0.1);
    }
    </style>
</head>
<body>
    <?php
    // Include database connection file
    include_once 'dbconnect.php';
    include_once 'adminsidebar.php';
    ?>
    <div class="main">
        <div class="topbar">
            <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
            </div>
        </div>

        <?php
        // Function to sanitize user input
        function sanitizeInput($input)
        {
            $input = trim($input);
            $input = stripslashes($input);
            $input = htmlspecialchars($input);
            return $input;
        }

        // Fetch all records
        $query = "SELECT * FROM booking where service_type= 'toy_bag_clean'";
        $result = $conn->query($query);
        ?>
        <table>
            <tr>
                <th>Booking Id</th>
                <th>Customer Name</th>
                <th>Service_type</th>
                <th>Cloth_type</th>
                <th>weight_combination</th>
                <th>exact_weight</th>
                <th>Rate price</th>
                <th>discount</th>
                <th>Total Price</th>
                <th>Pickup_date</th>
                <th>Delivery_date</th>
            </tr>
            <?php
            $rowNum = 0;
            while ($row = $result->fetch_assoc()) {
                $rowNum++;
                $rowColor = ($rowNum % 2 == 0) ? "#f9f9f9" : "#e5e5e5";

                echo "<tr style='background-color: $rowColor;'>";
                echo "<td>" . htmlspecialchars($row["booking_id"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["customer_name"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["service_type"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["cloth_type"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["weight_combination"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["exact_weight"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["price"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["discount"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["total_price"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["pickup_date"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["delivery_date"]) . "</td>";
                echo "<td>";
                echo "</div>";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>

    <script>
    // add hovered class to selected list item
    let list = document.querySelectorAll(".navigation li");

    function activeLink() {
        list.forEach((item) => {
            item.classList.remove("hovered");
        });
        this.classList.add("hovered");
    }

    list.forEach((item) => item.addEventListener("mouseover", activeLink));

    // Menu Toggle
    let toggle = document.querySelector(".toggle");
    let navigation = document.querySelector(".navigation");
    let main = document.querySelector(".main");

    toggle.onclick = function () {
        navigation.classList.toggle("active");
        main.classList.toggle("active");
    };
    </script>
</body>
</html>
