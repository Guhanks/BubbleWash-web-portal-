<?php
    include_once 'dbconnect.php';

if (isset($_GET['booking_id'])) {
    $bookingId = $_GET['booking_id'];

    // Database connection
    $mysqli = new mysqli("localhost", "root", "", "project");
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Deleting record
    $stmt = $mysqli->prepare("DELETE FROM booking WHERE booking_id = ?");
    $stmt->bind_param("s", $bookingId);

    if ($stmt->execute()) {
        echo "Record deleted successfully.";
        echo '<script>
                setTimeout(function() {
                    window.location.href = "adminbookings.php";
                }, 500); // 1000 milliseconds = 1 seconds
            </script>';
    } else {
        echo "Error deleting record: " . $stmt->error;
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo "Invalid request.";
}
?>