<?php
$servername = "localhost";
$dbname = "project";
$username = "root";
$password = "";

// Create a new connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Retrieving the booking ID from the query string
if (isset($_GET['booking_id'])) {
  $bookingId = $_GET['booking_id'];

  // Fetch the booking details
  $query = "SELECT * FROM booking WHERE booking_id = '$bookingId'";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) === 1) {
    $row = mysqli_fetch_assoc($result);

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $customerName = $_POST['customer_name'];
      $serviceType = $_POST['service_type'];
      $clothType = $_POST['cloth_type'];
      $weightCombination = $_POST['weight_combination'];
      $exactWeight = $_POST['exact_weight'];
      $pickupDate = $_POST['pickup_date'];
      $deliveryDate = $_POST['delivery_date'];

      // Calculate the price, discount, and total price
  // Calculate the price based on service type and cloth type
  $price = 0;
  if (($serviceType == 'dry_clean' || $serviceType == 'steam_iron') && ($clothType == 'shirt' || $clothType == 'tshirt' || $clothType == 'saree' || $clothType == 'chudi' || $clothType == 'suit_pant')) {
    $price = 10; // Price for dry clean and steam iron with cloth types shirt, tshirt, saree, chudi, suit-pant
  } elseif ($serviceType == 'bag_toy_wash' && ($clothType == 'nylon' || $clothType == 'woolen' || $clothType == 'jute')) {
    $price = 6; // Price for bag and toy wash with cloth types nylon, woolen, jute
  }

  // Calculate the discount based on weight
  $discount = 0;
  if ($weightCombination == 'less_than_10') {
    $discount = $price * $exactWeight * 0.05; // 5% discount for less than 10 kg
  } elseif ($weightCombination == 'more_than_10') {
    $discount = $price * $exactWeight * 0.2; // 20% discount for more than 10 kg
  }

  // Calculate the total price
  $totalPrice = $price * $exactWeight - $discount;

  $pickupDate = $_POST['pickup_date'];
  $deliveryDate = $_POST['delivery_date'];

      // Prepare the UPDATE statement
      $query = "UPDATE booking SET customer_name = '$customerName', service_type = '$serviceType', cloth_type = '$clothType', weight_combination = '$weightCombination', exact_weight = $exactWeight, price = $price, discount = $discount, total_price = $totalPrice, pickup_date = '$pickupDate', delivery_date = '$deliveryDate' WHERE booking_id = '$bookingId'";

      // Execute the UPDATE statement
      if (mysqli_query($conn, $query)) {
        $updateMessage = "<p style='color: green;'>Booking updated successfully.</p>";
      } else {
        $updateMessage = "<p style='color: red;'>Error updating booking: " . mysqli_error($conn) . "</p>";
      }
    }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Booking</title>
<style>
  body {
      font-family: Arial, sans-serif;
    }

    h1 {
      color: #333;
    }

    form {
      max-width: 400px;
      margin: 0 auto;
    }

    label {
      display: block;
      margin-bottom: 8px;
      color: #555;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      font-size: 14px;
      margin-bottom: 16px;
    }

    input[type="radio"] {
      margin-right: 8px;
    }

    input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 10px 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
  <script type="text/javascript">
    function updateClothTypes() {
      var serviceType = document.getElementById("service_type").value;
      var clothTypeSelect = document.getElementById("cloth_type");
      clothTypeSelect.innerHTML = ""; // Clear the existing options

      if (serviceType === "dry_clean" || serviceType === "steam_iron") {
        var clothTypes = ["shirt", "tshirt", "saree", "chudi", "suit_pant"];
      } else if (serviceType === "bag_toy_wash") {
        var clothTypes = ["nylon", "woolen", "jute"];
      }

      for (var i = 0; i < clothTypes.length; i++) {
        var option = document.createElement("option");
        option.value = clothTypes[i];
        option.text = clothTypes[i].charAt(0).toUpperCase() + clothTypes[i].slice(1);
        clothTypeSelect.appendChild(option);
      }

      updateCalculatedValues();
    }

    function updateCalculatedValues() {
      var priceInput = document.querySelector("input[name='price']");
      var discountInput = document.querySelector("input[name='discount']");
      var totalPriceInput = document.querySelector("input[name='total_price']");
      var serviceType = document.getElementById("service_type").value;
      var clothType = document.getElementById("cloth_type").value;
      var weightCombination = document.querySelector("input[name='weight_combination']:checked").value;
      var exactWeight = parseFloat(document.querySelector("input[name='exact_weight']").value);

      var price = 0;
      if ((serviceType === 'dry_clean' || serviceType === 'steam_iron') && (clothType === 'shirt' || clothType === 'tshirt' || clothType === 'saree' || clothType === 'chudi' || clothType === 'suit_pant')) {
        price = 10; // Price for dry clean and steam iron with cloth types shirt, tshirt, saree, chudi, suit-pant
      } else if (serviceType === 'bag_toy_wash' && (clothType === 'nylon' || clothType === 'woolen' || clothType === 'jute')) {
        price = 6; // Price for bag and toy wash with cloth types nylon, woolen, jute
      }

      var discount = 0;
      if (weightCombination === 'less_than_10') {
        discount = price * exactWeight * 0.05; // 5% discount for less than 10 kg
      } else if (weightCombination === 'more_than_10') {
        discount = price * exactWeight * 0.2; // 20% discount for more than 10 kg
      }

      var totalPrice = price * exactWeight - discount;

      priceInput.value = price.toFixed(2);
      discountInput.value = discount.toFixed(2);
      totalPriceInput.value = totalPrice.toFixed(2);
    }
    window.addEventListener("load", function () {
      // Clear form fields
      document.getElementById("customer_name").value = "";
      document.getElementById("service_type").value = "";
      document.getElementById("cloth_type").value = "";
      document.getElementById("weight_combination").value = "";
      document.getElementById("exact_weight").value = "";
      document.getElementById("pickup_date").value = "";
      document.getElementById("delivery_date").value = "";
      document.getElementById("price").value = "";
      document.getElementById("discount").value = "";
      document.getElementById("total_price").value = "";
    });
  </script>
</head>
<body>
  <h1>Edit Booking</h1>
  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?booking_id=<?php echo $bookingId; ?>">
  <?php echo isset($updateMessage) ? $updateMessage : ''; ?>
  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
   <label for="booking_id">Booking Id:</label>
    <input type="text" name="booking_id" value="<?php echo $row['booking_id']; ?>" required><br>
    <label for="customer_name">Customer Name:</label>
    <input type="text" name="customer_name" value="<?php echo $row['customer_name']; ?>" required><br>
    <label for="service_type">Service Type:</label>
    <input type="text" name="service_type" value="<?php echo $row['service_type']; ?>" required><br>
    <label for="cloth_type">Cloth Type:</label>
    <input type="text" name="cloth_type" value="<?php echo $row['cloth_type']; ?>" required><br>
    <label for="weight_combination">Weight Combination:</label>
    <input type="text" name="weight_combination" value="<?php echo $row['weight_combination']; ?>" required><br>
    <label for="exact_weight">Exact Weight:</label>
    <input type="text" name="exact_weight" value="<?php echo $row['exact_weight']; ?>" required><br>
    <label for="pickup_date">Pickup Date:</label>
    <input type="text" name="pickup_date" value="<?php echo $row['pickup_date']; ?>" required><br>
    <label for="delivery_date">Delivery Date:</label>
    <input type="text" name="delivery_date" value="<?php echo $row['delivery_date']; ?>" required><br>
    <label for="price">Price:</label>
    <input type="text" name="price" value="<?php echo $row['price']; ?>" required><br>
    <label for="discount">Discount:</label>
    <input type="text" name="discount" value="<?php echo $row['discount']; ?>" required><br>
    <label for="total_price">Total Price:</label>
    <input type="text" name="total_price" value="<?php echo $row['total_price']; ?>" required><br>
    <input type="submit" value="Update">
  </form>
</body>
</html>
<?php
  } else {
    echo "Invalid booking ID.";
  }

  // Close the connection
  mysqli_close($conn);
} else {
  echo "Booking ID not specified.";
}
?>
